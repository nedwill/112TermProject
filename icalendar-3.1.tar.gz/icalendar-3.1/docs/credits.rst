iCalendar contributors
======================

- Max M (maxm@mxm.dk) (Original author)

- Martijn Faassen (faassen@infrae.com)

- Lennart Regebro (lregebro@nuxeo.com)

- Sidnei da Silva (sidnei@enfoldsystems.com)

- Olivier Grisel (ogrisel@nuxeo.com)

- Michael Smith (msmith@fluendo.com)

- Hannes Raggam (johannes@raggam.co.at)

- Rok Garbas (rok@garbas.si)

- Robert Niederreiter (rnix@squarewave.at)
